package com.paykaro.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class CustomerException extends Exception {

	
	
}
