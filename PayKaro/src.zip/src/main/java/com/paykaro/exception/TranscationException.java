package com.paykaro.exception;

public class TranscationException extends RuntimeException {
	
	public TranscationException() {
		// TODO Auto-generated constructor stub
	}
	
	public TranscationException(String msg) {
		// TODO Auto-generated constructor stub
		  super(msg);
	}

}
