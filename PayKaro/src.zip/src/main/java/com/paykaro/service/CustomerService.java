package com.paykaro.service;

import com.paykaro.model.Customer;

public interface CustomerService {
	public Customer registerCusotmer(Customer customer);

}
