package com.paykaro.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paykaro.model.Customer;
import com.paykaro.repository.CustomerDAO;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDAO customerDAO;

	@Override
	public Customer registerCusotmer(Customer customer) {
		return customerDAO.save(customer);
	}

}
